package Clases;

import java.util.Date;

public interface IUsuario {

    String getRol();

    String getNombre();

    String getTidentificacion();

    String getIdentificacion();

    String getCorreo();

    String getTelefono();

    Date getNacimiento();

    String getSexo();

    String getEps();

}
