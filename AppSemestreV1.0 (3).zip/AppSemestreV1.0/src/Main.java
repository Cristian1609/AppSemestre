
import Clases.CConcretaDocente;
import Clases.IUsuario;
import java.util.Date;

public class Main {

    public static void main(String[] args) {

        String especialidad = "Matemáticas";
        String programa = "Educación Secundaria";
        String codigoInstitucional = "DOC12345";
        String correoInstitucional = "docente@example.edu";
        String contrasena = "password123";
        String tipo = "Titular";
        String rol = "Docente";
        String nombre = "Carlos Pérez";
        String tipoIdentificacion = "CC";
        String identificacion = "987654321";
        String correo = "carlos.perez@example.com";
        String telefono = "123456789";
        Date nacimiento = new Date(90, 2, 15);
        String sexo = "M";
        String eps = "SaludCoop";

        IUsuario docente = new CConcretaDocente(
                especialidad,
                programa,
                codigoInstitucional,
                correoInstitucional,
                contrasena,
                tipo,
                rol,
                nombre,
                tipoIdentificacion,
                identificacion,
                correo,
                telefono,
                nacimiento,
                sexo,
                eps
        );

        System.out.println("Especialidad: " + ((CConcretaDocente) docente).getEspecialidad());
        System.out.println("Programa: " + ((CConcretaDocente) docente).getPrograma());
        System.out.println("Código Institucional: " + ((CConcretaDocente) docente).getCodigI());
        System.out.println("Correo Institucional: " + ((CConcretaDocente) docente).getCorreoI());
        System.out.println("Contraseña: " + ((CConcretaDocente) docente).getContra());

        System.out.println("Rol: " + docente.getRol());
        System.out.println("Nombre: " + docente.getNombre());
        System.out.println("Tipo de Identificación: " + docente.getTidentificacion());
        System.out.println("Identificación: " + docente.getIdentificacion());
        System.out.println("Correo: " + docente.getCorreo());
        System.out.println("Teléfono: " + docente.getTelefono());
        System.out.println("Fecha de Nacimiento: " + docente.getNacimiento());
        System.out.println("Sexo: " + docente.getSexo());
        System.out.println("EPS: " + docente.getEps());
    }
}
