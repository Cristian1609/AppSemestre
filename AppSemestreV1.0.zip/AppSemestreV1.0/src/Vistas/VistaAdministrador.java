/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vistas;

import javax.swing.JOptionPane;

public class VistaAdministrador extends javax.swing.JFrame {

    private String dato;

    public VistaAdministrador() {
        initComponents();
    }

    public void setDato(String dato) {
        this.dato = dato;
        lblDato.setText("Bienvenido: " + dato);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        lblDato = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        lblUsuario = new javax.swing.JLabel();
        lblProgramaAcademico = new javax.swing.JLabel();
        lblCursos = new javax.swing.JLabel();
        lblSemestreAcademico = new javax.swing.JLabel();
        lblPensum = new javax.swing.JLabel();
        lblAsignaturas = new javax.swing.JLabel();
        lblEstudiantes = new javax.swing.JLabel();
        lblDocentes = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 0, 0));
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("X");
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 10, 36, -1));

        lblDato.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblDato.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblDato.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblDatoMouseClicked(evt);
            }
        });
        getContentPane().add(lblDato, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 6, 220, 32));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 44, 758, 10));

        lblUsuario.setBackground(new java.awt.Color(204, 204, 255));
        lblUsuario.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblUsuario.setForeground(new java.awt.Color(0, 0, 204));
        lblUsuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/lapiz-de-usuario.png"))); // NOI18N
        lblUsuario.setText("Usuarios");
        lblUsuario.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblUsuario.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblUsuario.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        lblUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblUsuarioMouseClicked(evt);
            }
        });
        getContentPane().add(lblUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, 140, 110));

        lblProgramaAcademico.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblProgramaAcademico.setForeground(new java.awt.Color(0, 0, 255));
        lblProgramaAcademico.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblProgramaAcademico.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/programa (1).png"))); // NOI18N
        lblProgramaAcademico.setText("Programa Academico");
        lblProgramaAcademico.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblProgramaAcademico.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblProgramaAcademico.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblProgramaAcademico.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        lblProgramaAcademico.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblProgramaAcademicoMouseClicked(evt);
            }
        });
        getContentPane().add(lblProgramaAcademico, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 80, 160, 110));

        lblCursos.setBackground(new java.awt.Color(204, 204, 255));
        lblCursos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCursos.setForeground(new java.awt.Color(0, 0, 204));
        lblCursos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCursos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/educacion (1).png"))); // NOI18N
        lblCursos.setText("Cursos");
        lblCursos.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblCursos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblCursos.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblCursos.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        getContentPane().add(lblCursos, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 260, 160, 110));

        lblSemestreAcademico.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblSemestreAcademico.setForeground(new java.awt.Color(0, 0, 255));
        lblSemestreAcademico.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSemestreAcademico.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/cronograma.png"))); // NOI18N
        lblSemestreAcademico.setText("Semestre Academico");
        lblSemestreAcademico.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblSemestreAcademico.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblSemestreAcademico.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblSemestreAcademico.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        lblSemestreAcademico.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblSemestreAcademicoMouseClicked(evt);
            }
        });
        getContentPane().add(lblSemestreAcademico, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 80, 150, 110));

        lblPensum.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblPensum.setForeground(new java.awt.Color(0, 0, 255));
        lblPensum.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPensum.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/acciones-de-tareas.png"))); // NOI18N
        lblPensum.setText("Pensum");
        lblPensum.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblPensum.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblPensum.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblPensum.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        lblPensum.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPensumMouseClicked(evt);
            }
        });
        getContentPane().add(lblPensum, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 80, 150, 110));

        lblAsignaturas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblAsignaturas.setForeground(new java.awt.Color(0, 0, 255));
        lblAsignaturas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAsignaturas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/educacion.png"))); // NOI18N
        lblAsignaturas.setText("Asignaturas");
        lblAsignaturas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblAsignaturas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblAsignaturas.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblAsignaturas.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        lblAsignaturas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAsignaturasMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblAsignaturasMouseEntered(evt);
            }
        });
        getContentPane().add(lblAsignaturas, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 140, 110));

        lblEstudiantes.setBackground(new java.awt.Color(204, 204, 255));
        lblEstudiantes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblEstudiantes.setForeground(new java.awt.Color(0, 0, 204));
        lblEstudiantes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEstudiantes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/libro-de-lectura.png"))); // NOI18N
        lblEstudiantes.setText("Estudiantes");
        lblEstudiantes.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblEstudiantes.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblEstudiantes.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblEstudiantes.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        lblEstudiantes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblEstudiantesMouseClicked(evt);
            }
        });
        getContentPane().add(lblEstudiantes, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 260, 150, 110));

        lblDocentes.setBackground(new java.awt.Color(204, 204, 255));
        lblDocentes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblDocentes.setForeground(new java.awt.Color(0, 0, 204));
        lblDocentes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDocentes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/docente.png"))); // NOI18N
        lblDocentes.setText("Docentes");
        lblDocentes.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblDocentes.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblDocentes.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblDocentes.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        lblDocentes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblDocentesMouseClicked(evt);
            }
        });
        getContentPane().add(lblDocentes, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 260, 150, 110));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Modulo Administrador");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, 650, 40));

        jLabel1.setBackground(new java.awt.Color(0, 0, 255));
        jLabel1.setForeground(new java.awt.Color(255, 51, 51));
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, 430));

        setSize(new java.awt.Dimension(750, 432));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        VistaIniciarSesion vi = new VistaIniciarSesion();
        JOptionPane.showMessageDialog(null,"Hasta pronto");
        this.setVisible(false);
        vi.setVisible(true);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void lblUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUsuarioMouseClicked
        this.setVisible(false);
        VistaGestionUsuarios vgu = new VistaGestionUsuarios();
        vgu.setDato(dato);
        vgu.setVisible(true);

    }//GEN-LAST:event_lblUsuarioMouseClicked

    private void lblDatoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDatoMouseClicked
        this.setVisible(false);
        VistaGestionDatosAdmin Vgda = new VistaGestionDatosAdmin();
        Vgda.setDato(dato);
        Vgda.setVisible(true);
    }//GEN-LAST:event_lblDatoMouseClicked

    private void lblProgramaAcademicoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProgramaAcademicoMouseClicked
        this.setVisible(false);
        VistaPrograma vp = new VistaPrograma();
        vp.setDato(dato);
        vp.setVisible(true);
    }//GEN-LAST:event_lblProgramaAcademicoMouseClicked

    private void lblSemestreAcademicoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSemestreAcademicoMouseClicked
        this.setVisible(false);
        VistaSemestre vs = new VistaSemestre();
        vs.setDato(dato);
        vs.setVisible(true);
    }//GEN-LAST:event_lblSemestreAcademicoMouseClicked

    private void lblPensumMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPensumMouseClicked
        this.setVisible(false);
        VistaPensum vp = new VistaPensum();
        vp.setDato(dato);
        vp.setVisible(true);
    }//GEN-LAST:event_lblPensumMouseClicked

    private void lblAsignaturasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAsignaturasMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_lblAsignaturasMouseEntered

    private void lblAsignaturasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAsignaturasMouseClicked
        this.setVisible(false);
        VistaAsignatura Va = new VistaAsignatura();
        Va.setDato(dato);
        Va.setVisible(true);

    }//GEN-LAST:event_lblAsignaturasMouseClicked

    private void lblEstudiantesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEstudiantesMouseClicked
        this.setVisible(false);
        RegistroAlumno ra = new RegistroAlumno();
        ra.setDato(dato);
        ra.setVisible(true);
    }//GEN-LAST:event_lblEstudiantesMouseClicked

    private void lblDocentesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDocentesMouseClicked
        this.setVisible(false);
        RegistroDocente rd = new RegistroDocente();
        rd.setDato(dato);
        rd.setVisible(true);

    }//GEN-LAST:event_lblDocentesMouseClicked

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblAsignaturas;
    private javax.swing.JLabel lblCursos;
    private javax.swing.JLabel lblDato;
    private javax.swing.JLabel lblDocentes;
    private javax.swing.JLabel lblEstudiantes;
    private javax.swing.JLabel lblPensum;
    private javax.swing.JLabel lblProgramaAcademico;
    private javax.swing.JLabel lblSemestreAcademico;
    private javax.swing.JLabel lblUsuario;
    // End of variables declaration//GEN-END:variables
}
