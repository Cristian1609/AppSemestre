package Factory;

import BD.Conexion;
import Clases.CConcretaAlumno;
import Clases.CConcretaDocente;
import Clases.IUsuario;
import com.toedter.calendar.JDateChooser;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class SQLUsuarioFactory extends BD.Conexion {

    public static int RegistrarUsuario(JTextField txtNombre, JComboBox<String> comboTipoIdentificación, JTextField txtNúmeroIdentificación,
            JTextField txtCorreoPersonal, JTextField txtTeléfono, JDateChooser jcalendarNacimiento, JComboBox<String> comboSexo,
            JComboBox<String> comboEps, UsuarioFactory factory, JTextField txtRol, JComboBox<String> comboPrograma) throws SQLException {

        IUsuario usuario = factory.crearUsuario(
                txtRol.getText(),
                txtNombre.getText(),
                comboTipoIdentificación.getSelectedItem().toString(),
                txtNúmeroIdentificación.getText(),
                txtCorreoPersonal.getText(),
                txtTeléfono.getText(),
                new Date(jcalendarNacimiento.getDate().getTime()),
                comboSexo.getSelectedItem().toString(),
                comboEps.getSelectedItem().toString(),
                comboPrograma.getSelectedItem().toString(),
                "",
                "",
                "",
                "",
                txtRol.getText()
        );
        Connection conn = new Conexion().conectar();
        String sql = "INSERT INTO Usuario (id_rol, nombre_completo, id_tipo_identificacion, numero_identificacion, correo_personal, telefono, fecha_nacimiento, id_sexo, id_eps) "
                + "VALUES ("
                + "(SELECT id FROM Rol WHERE nombre = ?), "
                + "?, "
                + "(SELECT id FROM tipo_identificacion WHERE nombre = ?), "
                + "?, "
                + "?, "
                + "?, "
                + "?, "
                + "(SELECT id FROM Sexo WHERE nombre = ?), "
                + "(SELECT id FROM Eps WHERE nombre = ?)"
                + ")";

        int nuevoIdUsuario = -1;

        try (PreparedStatement pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, txtRol.getText());
            pstmt.setString(2, usuario.getNombre());
            pstmt.setString(3, comboTipoIdentificación.getSelectedItem().toString());
            pstmt.setString(4, txtNúmeroIdentificación.getText());
            pstmt.setString(5, txtCorreoPersonal.getText());
            pstmt.setString(6, txtTeléfono.getText());
            pstmt.setDate(7, new Date(jcalendarNacimiento.getDate().getTime()));
            pstmt.setString(8, comboSexo.getSelectedItem().toString());
            pstmt.setString(9, comboEps.getSelectedItem().toString());

            pstmt.executeUpdate();

            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                nuevoIdUsuario = generatedKeys.getInt(1);
            } else {
                throw new SQLException("No se pudo obtener el ID del nuevo usuario.");
            }

        } catch (SQLException e) {
            System.out.println("Error al insertar usuario: " + e.getMessage());
            throw e;
        }

        return nuevoIdUsuario;
    }

    public static void RegistrarDocente(Connection conn, int idUsuario, UsuarioFactory factory, JComboBox<String> comboEspecialidad,
            JComboBox comboPrograma, JTextField txtCodigoInstitucional, JTextField txtCorreoInstitucional,
            JTextField txtContraseña, IUsuario usuario) throws SQLException {
        if (usuario instanceof CConcretaDocente) {

            String especialidad = (String) comboEspecialidad.getSelectedItem();
            String programa = (String) comboPrograma.getSelectedItem();
            String codigoInstitucional = txtCodigoInstitucional.getText();
            String correoInstitucional = txtCorreoInstitucional.getText();
            String contrasena = txtContraseña.getText();

            String sql = "INSERT INTO Docente (id_usuario, id_especialidad, id_programa, codigo_institucional, correo_institucional, contraseña) "
                    + "VALUES ("
                    + "?, "
                    + "(SELECT id FROM especialidad WHERE nombre = ?), "
                    + "(SELECT id FROM programa WHERE nombre = ?), "
                    + "?, "
                    + "?, "
                    + "?)";

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setInt(1, idUsuario);
                pstmt.setString(2, especialidad);
                pstmt.setString(3, programa);
                pstmt.setString(4, codigoInstitucional);
                pstmt.setString(5, correoInstitucional);
                pstmt.setString(6, contrasena);

                int affectedRows = pstmt.executeUpdate();
                if (affectedRows == 0) {
                    JOptionPane.showMessageDialog(null, "No se pudo crear correctamente");
                }
                JOptionPane.showMessageDialog(null, "Creado correctamente");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);

            }
        }
    }

    public static void RegistrarAlumno(Connection conn, int idUsuario, UsuarioFactory factory, JComboBox comboPrograma,
            JTextField txtCodigoInstitucional, JTextField txtCorreoInstitucional, JTextField txtContraseña, IUsuario usuario) throws SQLException {
        if (usuario instanceof CConcretaAlumno) {

            String programa = (String) comboPrograma.getSelectedItem();
            String codigoInstitucional = txtCodigoInstitucional.getText();
            String correoInstitucional = txtCorreoInstitucional.getText();
            String contrasena = txtContraseña.getText();

            String sql = "INSERT INTO Alumno (id_usuario, id_programa, codigo_institucional, correo_institucional, contraseña) "
                    + "VALUES ("
                    + "?, "
                    + "(SELECT id FROM programa WHERE nombre = ?), "
                    + "?, "
                    + "?, "
                    + "?)";

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setInt(1, idUsuario);
                pstmt.setString(2, programa);
                pstmt.setString(3, codigoInstitucional);
                pstmt.setString(4, correoInstitucional);
                pstmt.setString(5, contrasena);

                int affectedRows = pstmt.executeUpdate();
                if (affectedRows == 0) {
                    JOptionPane.showMessageDialog(null, "No se pudo crear correctamente");
                }

                JOptionPane.showMessageDialog(null, "Creado Correctamente");

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);

            }
        }
    }

    public boolean MostrarAlumno(JTable jTable1) {
        String sql = "SELECT "
                + "u.nombre_completo, "
                + "ti.nombre AS tipo_identificacion, "
                + "u.numero_identificacion, "
                + "u.correo_personal, "
                + "u.telefono, "
                + "u.fecha_nacimiento, "
                + "s.nombre AS sexo, "
                + "e.nombre AS eps, "
                + "prog.nombre AS programa, "
                + "a.codigo_institucional, "
                + "a.correo_institucional "
                + "FROM "
                + "usuario u "
                + "JOIN alumno a ON u.id = a.id_usuario "
                + "JOIN tipo_identificacion ti ON u.id_tipo_identificacion = ti.id "
                + "JOIN sexo s ON u.id_sexo = s.id "
                + "JOIN eps e ON u.id_eps = e.id "
                + "JOIN programa prog ON a.id_programa = prog.id";

        Conexion con = new Conexion();
        Connection cox = con.conectar();

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Nombre Completo");
        model.addColumn("Tipo de Identificación");
        model.addColumn("Número de Identificación");
        model.addColumn("Correo Personal");
        model.addColumn("Teléfono");
        model.addColumn("Fecha de Nacimiento");
        model.addColumn("Sexo");
        model.addColumn("EPS");
        model.addColumn("Programa");
        model.addColumn("Código Institucional");
        model.addColumn("Correo Institucional");

        jTable1.setModel(model);

        try {
            Statement st = cox.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String[] datos = new String[11];
                datos[0] = rs.getString("nombre_completo");
                datos[1] = rs.getString("tipo_identificacion");
                datos[2] = rs.getString("numero_identificacion");
                datos[3] = rs.getString("correo_personal");
                datos[4] = rs.getString("telefono");
                datos[5] = rs.getString("fecha_nacimiento");
                datos[6] = rs.getString("sexo");
                datos[7] = rs.getString("eps");
                datos[8] = rs.getString("programa");
                datos[9] = rs.getString("codigo_institucional");
                datos[10] = rs.getString("correo_institucional");

                model.addRow(datos);
            }

            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
            return false;
        }
    }

    public boolean MostrarDocente(JTable jTable1) {
        String sql = "SELECT "
                + "u.nombre_completo, "
                + "ti.nombre AS tipo_identificacion, "
                + "u.numero_identificacion, "
                + "u.correo_personal, "
                + "u.telefono, "
                + "u.fecha_nacimiento, "
                + "s.nombre AS sexo, "
                + "e.nombre AS eps, "
                + "esp.nombre AS especialidad, "
                + "prog.nombre AS programa, "
                + "d.codigo_institucional, "
                + "d.correo_institucional "
                + "FROM "
                + "usuario u "
                + "JOIN docente d ON u.id = d.id_usuario "
                + "JOIN tipo_identificacion ti ON u.id_tipo_identificacion = ti.id "
                + "JOIN sexo s ON u.id_sexo = s.id "
                + "JOIN eps e ON u.id_eps = e.id "
                + "JOIN especialidad esp ON d.id_especialidad = esp.id "
                + "JOIN programa prog ON d.id_programa = prog.id";

        Conexion con = new Conexion();
        Connection cox = con.conectar();

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Nombre Completo");
        model.addColumn("Tipo de Identificación");
        model.addColumn("Número de Identificación");
        model.addColumn("Correo Personal");
        model.addColumn("Teléfono");
        model.addColumn("Fecha de Nacimiento");
        model.addColumn("Sexo");
        model.addColumn("EPS");
        model.addColumn("Especialidad");
        model.addColumn("Programa");
        model.addColumn("Código Institucional");
        model.addColumn("Correo Institucional");

        jTable1.setModel(model);

        try {
            Statement st = cox.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String[] datos = new String[12];
                datos[0] = rs.getString("nombre_completo");
                datos[1] = rs.getString("tipo_identificacion");
                datos[2] = rs.getString("numero_identificacion");
                datos[3] = rs.getString("correo_personal");
                datos[4] = rs.getString("telefono");
                datos[5] = rs.getString("fecha_nacimiento");
                datos[6] = rs.getString("sexo");
                datos[7] = rs.getString("eps");
                datos[8] = rs.getString("especialidad");
                datos[9] = rs.getString("programa");
                datos[10] = rs.getString("codigo_institucional");
                datos[11] = rs.getString("correo_institucional");

                model.addRow(datos);
            }

            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR: " + e.getMessage());
            return false;
        }

    }

}
